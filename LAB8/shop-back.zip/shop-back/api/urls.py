from itertools import product
from django.urls import path
from api.views import category_detail, category_list, category_product, product_detail, product_list


urlpatterns = [
    path('products/', product_list),
    path('products/<int:product_id>/', product_detail),
    path('categories/', category_list),
    path('categories/<int:category_id>/', category_detail),
    path('categories/<int:category_id>/products/', category_product)
]