from itertools import product
from unicodedata import category
from django.urls import path
from api.views import company_detail, company_list, vacancy_detail, vacancy_list

urlpatterns = [
    path('companies/', company_list),
    path('vacancies/', vacancy_list),
    path('companies/<int:company_id>/', company_detail),
    path('vacancies/<int:company_id>/', vacancy_detail)

]